﻿using UnityEngine;

public class EditorDisabledAttribute : PropertyAttribute {

}
